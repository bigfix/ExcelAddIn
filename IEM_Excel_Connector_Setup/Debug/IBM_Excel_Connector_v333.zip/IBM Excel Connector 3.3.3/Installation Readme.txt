IBM Excel Connector 3.3.3 (April 16th, 2013)

- Uninstall previous version if exists.

- If the add-in does not show up in Excel or if encounter errors, use setup.exe,
  then right-click and run as Administrator to install.

- If the system has .NET Framework 4.0, it has to be the full version, not Client Profile.
  Instruction here: http://forum.bigfix.com/viewtopic.php?pid=24824#p24824

- The installer log file is located at \user_home\Add-in Express. Any errors will be
  visible there.

- The BigFixExcelConnectorExamples.bce is an export file.
  Import from the add-in to see some example queries.
  
- Watch some clips about the Excel Connnector
	Extract Computer Properties
	http://leewei.com/bigfix/prod/excelconnector/BESComputers/BESComputers.html (47 secs)

	Single Property Summary
	http://leewei.com/bigfix/prod/excelconnector/BESProperties/BESProperties.html (34 secs)

	Import, Open and Save Queries
	http://leewei.com/bigfix/prod/excelconnector/ImportOpenSave/ImportOpenSave.html (1 min 28 secs)

	Show Generated Relevance Code
	http://leewei.com/bigfix/prod/excelconnector/ShowRelevance/ShowRelevance.html (1 min 21 secs)	

Post questions at http://forum.bigfix.com/viewtopic.php?id=3564&p=1

